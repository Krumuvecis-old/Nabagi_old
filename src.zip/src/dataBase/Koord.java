package dataBase;

public class Koord {
	//objektu kust�bas atvieglo�anai - pamatparametri
	public double x, y, v, fi;
}
