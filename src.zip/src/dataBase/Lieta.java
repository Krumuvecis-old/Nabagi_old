package dataBase;

public class Lieta {
	public double x;
	public double y;
	public String nosaukums;
	public double daudzums;
	public double zelts;
	public double paika;
	public double masa;
	public double attack;
	public double defence;
	public double condition;
}