package konstantes;

class Misc {
	protected static void initialize() {
		
		Parametri.komandaNosaukumsDefault="K";
		Parametri.komandaIzjuktChance=0.3;
	}
	
}
