package dataBase;

import java.awt.Color;

public class Komanda {
	
	public static int maxKomanda=0; //numer�cija nosaukuma do�anai, lai neatk�rtotos nosaukumi
	
	
	public String nosaukums;
	public String galvenais;
	public Color krasa;
	public int skaits;
	
	
}
