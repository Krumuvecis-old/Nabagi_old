package galvenais;

//import konstantes.Parametri;
import komandas.KomanduApskats;
import cilveki.CilvekuApskats;

class GalvenaisCikls {
	
	protected static void main(){
		Lietas.main(); //viss kas saist�ts ar pa  zemi izm�t�taj�m liet�m
		KomanduApskats.main(); //viss kas saist�ts ar komand�m
		CilvekuApskats.main(); //viss kas saist�ts ar cilv�kiem
	}
	
}
