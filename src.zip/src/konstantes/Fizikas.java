package konstantes;

class Fizikas {
	
	protected static void initialize() {
		Parametri.platums=1200; //laukuma izm�ri (ieskaitot malu)
		Parametri.augstums=650;
		
		Parametri.mala=10 ; //laukuma mala
		
		Parametri.lietasResnums=10; // default neklasific�tai lietai
		Parametri.zeltaResnums=7; //zeltam
		Parametri.paikasResnums=8; //paikai
		
		Parametri.resnumaKoefic=0.7; //cilv�ka resnuma koeficients (noteik�anai p�c hpMax)
	}
}
