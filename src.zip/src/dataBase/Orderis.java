package dataBase;

public class Orderis {
	public String prece;
	public boolean perk;
	public double cena;
	public double daudzums;
}
