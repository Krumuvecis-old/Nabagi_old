module testaModulis {
	requires java.desktop;
}